# PHTB-
Hack/Recover Wifi or Files Password using Bute-Force method. (Legal)

# Notes
Eventhough it's LEGAL to crack password using brute-force method.It's still ILLEGAL to crack password without the agreement with the owner.

# PHTB have 7 main modules,which is:
# 1. Aircrack-ng
# 2. Kraken
# 3. Password Dictionary
# 4. Router Scan
# 5. Wifi Brute-Force by TUX
# 6. LostMyPass
# 7. Wi-Fi Pass-View by KARIN
# 8. Cain and Abel

# How to use
# Aircrack-ng
To use Aircrack-ng,please refer to this link down below:
# https://www.youtube.com/watch?v=usrl-_eceSs&t=205s

# Kraken
Kraken is a tool to crack/recover .zip,.tar and .rar archive.It is one of the fastest tools to crack those archive.
# How to use?
It is very easy to use Kraken.
First you need to move the encrypted file to Recovery Folder,
then you need to open Kraken,
after that,You need to navigate through the menu.
# [Notes]
Please note that you need the latest .NET Framework for Kraken to work.
# 
if you want to use dictionary attack,just open the Password Dictionary file,then open any folder inside the file.After that,just move the passlist.txt file to the Dictionary folder.

# Password Dictionary
I am pretty sure that everyone already know what this folder is.

# Router Scan
Router Scan is a tool to scan wifi around you.One of it's ability is is Wifi bruteforcing.
# How to use?
To use it,First you need to open the Router Scan application,Then open the Wireless Network tab.Turn on enable discovery and cumulative mode.Then right click any network.
After you right click the network,you will se the option.Select Brute-Force Network.Then tap on the dict.Select the password dictionary file that i have given.Then clck start audit button.

# Wifi Brute-Force by TUX
Wifi Brute-Force by TUX is well,Wifi brute-forcer.
# How to use?
In the file,there is source code file,open it.Then,open keycombinator.After you finish the survey in the keycombinator file,open bruteforce.Type help.You can get the list of all the command available.
# [Notes]
To use dictionary attack,just copy the passlist.txt file from the password dictionary file.

# LostMyPass
LostMyPass is a website archived file password cracker.It is really fast at cracking password.
# How to use?
Open the batch file.Complete!

# Wi-FI Pass-View By KARIN
Wi-FI Pass-View by KARIN will show all the wireless Wi-FI Password stored in your computer.
# How to use?
Simply Just Launch The Batch Files

# Cain and Abel
Cain and Abel is multifunctional password recovery tool.
# How to use?
I cannot explain how to use it because it's very complicated,however,You can still search in youtube
about it.